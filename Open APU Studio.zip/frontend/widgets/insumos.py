"""
insumos.py
==========
Tabla plana del catálogo de insumos.

Uso:
    from frontend.widgets.insumos import TablaInsumos
"""

from PySide6.QtCore import QByteArray, Signal
from PySide6.QtWidgets import QHeaderView, QMenu
from frontend.widgets.base import TreeTableWidget
from backend.db import Config


# ── Configuración de columnas ─────────────────────────────────────

COLUMNAS = [
    "Clave", "Descripción", "Unidad", "Precio", "Tipo",
    "Familia", "Proveedor", "F. Precio", "Desc. Corta", "Costo MN", "Costo ME",
]
EDITABLE = frozenset()

# ── Mapeo tipo_id → nombre ───────────────────────────────────────

TIPO_NOMBRE = {
    1:  "🧱 Material",
    2:  "👷 Mano de obra",
    4:  "🔧 Herramienta",
    8:  "🚜 Equipo",
    16: "⚙️ Auxiliar",
    32: "📄 Concepto",
    64: "🚛 Flete",
    128:"🏗️ Trabajo",
}


# ── Tabla plana de insumos ────────────────────────────────────────

class TablaInsumos(TreeTableWidget):
    """Tabla plana del catálogo de insumos (sin jerarquía).
    Guarda el estado del header en config.json para persistir anchos
    y visibilidad de columnas entre sesiones.
    """
    _HEADER_KEY = "insumos_header_state"
    rastrear_insumo = Signal(str)  # clave

    def __init__(self, parent=None):
        """Inicializa tabla plana de insumos con columnas, modos, búsqueda y restauración del header."""
        super().__init__(COLUMNAS, EDITABLE, flat=True, parent=parent)
        self.set_column_modes({
            c: (QHeaderView.ResizeMode.Interactive, w)
            for c, w in enumerate([90, 250, 60, 100, 120, 120, 140, 85, 140, 95, 95])
        })
        self.header().setMaximumSectionSize(400)
        # columnas de detalle ocultas por defecto
        for c in (7, 8, 9, 10):
            self.setColumnHidden(c, True)
        # búsqueda por defecto: Clave, Descripción, Familia
        # (Desc. Corta disponible en el menú pero no tildada por defecto)
        self._search_cols = {0, 1, 5}
        self._restore_header_state()

    def contextMenuEvent(self, event):
        """Menú contextual sobre insumo seleccionado: opción 'Rastrear uso' si hay una sola selección."""
        items = self.selectedItems()
        if len(items) != 1:
            super().contextMenuEvent(event)
            return
        item = items[0]
        menu = QMenu(self)
        act = menu.addAction("\U0001f50d Rastrear uso")
        act.triggered.connect(lambda: self._emit_rastrear(item))
        menu.exec(event.globalPos())

    def _emit_rastrear(self, item):
        """Emite señal rastrear_insumo con la clave del item seleccionado."""
        clave = item.text(0)
        if clave:
            self.rastrear_insumo.emit(clave)

    def _header_context_menu(self, pos):
        """Extiende menú contextual de cabecera y persiste estado tras cambios."""
        super()._header_context_menu(pos)
        self._save_header_state()

    def _save_header_state(self):
        """Guarda estado del header (anchos, visibilidad) en config.json como base64."""
        raw = self.header().saveState()
        Config.set(self._HEADER_KEY, raw.toBase64().data().decode("ascii"))

    def _restore_header_state(self):
        """Restaura estado guardado del header desde config.json si existe."""
        saved = Config.get(self._HEADER_KEY)
        if saved:
            self.header().restoreState(QByteArray.fromBase64(saved.encode("ascii")))

    # ── Poblado de la tabla ───────────────────────────────────────

    def poblar(self, insumos: list[dict], claves_con_apu: set[str] | None = None):
        """
        Puebla la tabla desde una lista de dicts devuelta por InsumoRepo.
        Si claves_con_apu se provee, antepone ▶ a la descripción de compuestos.
        """
        self.clear()
        for ins in insumos:
            clave     = ins.get("clave", "")
            tipo_id   = ins.get("tipo_id") or ins.get("tipo", 0)
            tipo_txt  = TIPO_NOMBRE.get(tipo_id) or ins.get("tipo_nombre") or f"Tipo {tipo_id}"
            precio    = ins.get("costo_final", 0) or 0
            desc      = ins.get("descripcion") or ins.get("descripcion_corta") or ""
            if claves_con_apu and clave in claves_con_apu:
                desc = f"\u25b6 {desc}"
            self.add_row([
                clave,
                desc,
                ins.get("unidad", "") or "",
                f"${precio:,.2f}",
                tipo_txt,
                # Familia › Subfamilia (se concatenan si existe subfamilia)
                (lambda f, s: f"{f} › {s}" if s else f)(
                    ins.get("familia_nombre") or "",
                    ins.get("subfamilia_nombre") or "",
                ),
                ins.get("proveedor_nombre") or "",
                ins.get("fecha_precio") or "",
                ins.get("descripcion_corta") or "",
                f"${ins.get('costo_mn', 0) or 0:,.2f}",
                f"${ins.get('costo_me', 0) or 0:,.2f}",
            ], editable=False)
